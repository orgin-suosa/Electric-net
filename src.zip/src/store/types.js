export const CLIENT_LIST = 'CLIENT_LIST' //客户原始值
export const CLIENT_LIST_GAIN = 'CLIENT_LIST_GAIN' //客户列表
export const CLIENT_LIST_RECORD = 'CLIENT_LIST_RECORD' //客户列表切换
export const SEND_MESSAGE = 'SEND_MESSAGE' //客户列表轮训
export const CLIENT_COMPILE = 'CLIENT_COMPILE' //编辑
export const CLIENT_PORTRAYAL = 'CLIENT_PORTRAYAL' //客户画像
export const CLIENT_FOOTER = 'CLIENT_FOOTER' //客户足迹
export const SEND_MOULDES = 'SEND_MOULDES' //可选内容区发送模版
export const TITLELISTDATA = 'TITLELISTDATA' //可选内容区发送模版
export const SAVELISTDATA = 'SAVELISTDATA' //保存名片
export const RESTORDATA = 'RESTORDATA' //还原数据
export const QRCODELOGION = 'QRCODELOGION' //员工绑定生成二维码
export const MODELLIST = 'MODELLIST' //员工绑定生成二维码
export const SHOWTM = 'SHOWTM' //模版预览
export const TEMPWECHAT = 'TEMPWECHAT' //微信发送
export const TEMPSMS = 'TEMPSMS' //短信发送
export const UPDATACHAT = 'UPDATACHAT' //会话开关
export const TO_LOGION_CKECK = 'TO_LOGION_CKECK' //会话开关
export const MESSAGE_LX = 'MESSAGE_LX' //消息轮循
export const NOTHINGMESSAGE = 'NOTHINGMESSAGE' //离线消息
export const RETURNDX = 'RETURNDX' //离线消息
export const GET_MORE_MESS = 'GET_MORE_MESS' //滚动消息刷新
export const UPDATACHATSTATUS = 'UPDATACHATSTATUS' //滚动消息刷新updateChatStatus
export const PISDEFAULT = 'PISDEFAULT' //滚动消息刷新updateChatStatus
export const TSRUNBIND = 'TSRUNBIND' //解绑工号 getTSRhead
export const GETTSRHEAD = 'GETTSRHEAD' //更新头像 getTSRhead
export const VOICERECORD = 'VOICERECORD' //生成图片方法名 getVoiceRecord
export const GETCLIENTPHONENO = 'GETCLIENTPHONENO' //生成图片方法名 getVoiceRecord
export const GETJHSMESSAGE = 'GETJHSMESSAGE' //计划书确认书 getJhsMessage
export const QUERYPROCODE = 'QUERYPROCODE' //获取员工编号赵盼


//快捷回复接口
export const GETFASTREPLY = 'GETFASTREPLY' //获取
export const ADDFASTREPLY = 'ADDFASTREPLY' //添加
